from datetime import datetime
from subscripts.userStories.UserStoriesDP import getIndiByID, getFamByID
from subscripts.userStories.UserStoriesVD import getNamebyId ,getAliveById

from datetime import datetime
from datetime import date
from prettytable import PrettyTable
# Marriage before death
def us05(indi, fam, f):
    print("User Story 5 - Marriage before death, Running")
    flag = True
    for families in fam:
        for individuals in indi:
            # checking for husband id is equal to individual id
            if families['HUSB'] == individuals['INDI']:
                # getting death date for husband individual
                m = individuals['DEAT']
                # If individual's death date is not null
                if m != 'NA':
                    # checking for marriage date greater than the individual's death date
                    if families['MARR'] > m:
                        f.write(
                            f"ERROR: INDIVIDUAL : US05 : {individuals['INDI']} : Married {families['MARR']} after husband's ({individuals['INDI']}) death on {individuals['DEAT']} \n")
                        flag = False

            # checking for wife id is equal to individual id
            elif families['WIFE'] == individuals['INDI']:
                # getting death date for wifi individual
                n = individuals['DEAT']
                # If individual's death date is not null
                if n != 'NA':
                    # checking for marriage date greater than the individual's death date
                    if families['MARR'] > n:
                        f.write(
                            f"ERROR: INDIVIDUAL : US05 : {individuals['INDI']} : Married {families['MARR']} after wifi's ({individuals['INDI']}) death on {individuals['DEAT']} \n")
                        flag = False

    print("User Story 5 Completed")
    return flag

# User Story 18, siblings should not marry each other
def us18(indi, fam, f):
    flag = True
    print("User Story 18 - Siblings should not marry each other, running")
    for family in fam:
        husb = getIndiByID(indi, family["HUSB"])
        wife = getIndiByID(indi, family["WIFE"])
        if husb["FAMC"] == wife["FAMC"] and husb["FAMC"] != "NA" and wife["FAMC"] != "NA":
            print(f'Error: FAMILY: US18: spouses {family["HUSB"]} and {family["WIFE"]} are siblings')
            f.write(f'Error: FAMILY: US18: spouses {family["HUSB"]} and {family["WIFE"]} are siblings \n')
            flag = False
    print("User Story 18 Completed")
    return flag


def us19(indi, fam, f):
    flag = True
    print("User Story 19 - First cousins should not marry, running")
    for family in fam:
        husband = getIndiByID(indi, family["HUSB"])
        if husband["FAMC"] != 'NA':
            husbandfamc = getFamByID(fam, husband["FAMC"][0])
            if husbandfamc["HUSB"] != 'NA':
                grandfather = getIndiByID(indi, husbandfamc["HUSB"])
                if grandfather["FAMC"] != 'NA':
                    grandfatherfamc = getFamByID(fam, grandfather["FAMC"][0])
                else:
                    grandfatherfamc = 0
            if husbandfamc["WIFE"] != 'NA':
                grandmother = getIndiByID(indi, husbandfamc["WIFE"])
                if grandmother["FAMC"] != 'NA':
                    grandmotherfamc = getFamByID(fam, grandmother["FAMC"][0])
                else:
                    grandmotherfamc = 1
        wife = getIndiByID(indi, family["WIFE"])
        if wife["FAMC"] != 'NA':
            wifefamc = getFamByID(fam, wife["FAMC"][0])
            if wifefamc["HUSB"] != 'NA':
                wgrandfather = getIndiByID(indi, wifefamc["HUSB"])
                if wgrandfather["FAMC"] != 'NA':
                    wgrandfatherfamc = getFamByID(fam, wgrandfather["FAMC"][0])
                else:
                    wgrandfatherfamc = 2
            if wifefamc["WIFE"] != 'NA':
                wgrandmother = getIndiByID(indi, wifefamc["WIFE"])
                if wgrandmother["FAMC"] != 'NA':
                    wgrandmotherfamc = getFamByID(fam, wgrandmother["FAMC"][0])
                else:
                    wgrandmotherfamc = 3

            if wgrandfatherfamc == grandfatherfamc or wgrandfatherfamc == grandmotherfamc or wgrandmotherfamc == grandmotherfamc or wgrandmotherfamc == grandfatherfamc:
                print(f'Error: FAMILY: US19: spouses {family["HUSB"]} and {family["WIFE"]} are first cousins')
                f.write(f'Error: FAMILY: US19: spouses {family["HUSB"]} and {family["WIFE"]} are first cousins'+'\n')
                flag = False

    print("User Story 19 Completed")
    return flag


def us20(indi, fam, f):
    print("User Story 20 - Aunts and Uncles should not marry their nieces and nephews , Running")
    flag = True
    for individual in indi:
        if individual["FAMC"] == "NA" or individual["FAMS"] == "NA":
            continue
        # get parents of spouses for an individual
        parents_of_spouses = list()
        spouse_gender = "HUSB"
        if individual["SEX"] == "M":
            spouse_gender = "WIFE"
        for family_id in individual["FAMS"]:
            family = getFamByID(fam, family_id)
            spouse = getIndiByID(indi, family[spouse_gender])
            if spouse["FAMC"] == "NA":
                continue
            else:
                famc_spouse = getFamByID(fam, spouse["FAMC"][0])
                parents_of_spouses.append((spouse["INDI"], famc_spouse["HUSB"]))
                parents_of_spouses.append((spouse["INDI"], famc_spouse["WIFE"]))
        if len(parents_of_spouses) == 0:
            continue

        # for an individual check in "FAMC", if siblings are present as parents of spouses
        famc_individual = getFamByID(fam, individual["FAMC"][0])
        for child in famc_individual["CHIL"]:
            if child == individual["INDI"]:
                continue
            for spouse, parent in parents_of_spouses:
                if child == parent:
                    flag = False
                    print(f"Error: US 20 Individual {spouse} has married their aunt/uncle {individual['INDI']}")
                    f.write(f"Error: US 20 Individual {spouse} has married their aunt/uncle {individual['INDI']}"+"\n")

    print("User Story 20 Completed")
    return flag


def us23(indi, fam, f):
    print("Starting User Story 23 - No more than one individual with the same name and birth date should appear in a GEDCOM file")
    flag=True
    for fa in fam:
        n=len(fa["CHIL"])
        name=[]*n
        birth=[]*n
        if(n>1 and fa["CHIL"]!="NA"):
            for i in range(n):
                for j in indi:
                    if(fa["CHIL"][i]==j["INDI"]):
                        name.append(j["NAME"])
                        birth.append(j["BIRT"])
            if(len(name)==len(birth)):
                seen=set()
                dat=set()
                for s in name:
                    if s in seen:
                        for d in birth:
                            if d in dat:
                                print(f"Error: US 23 one individual with the same name {s} and birth date {d}")
                                f.write(f"Error: US 23 one individual with the same name {s} and birth date {d}" +"\n")
                            dat.add(d)
                    seen.add(s)
    print("User Story 23 Completed")
    return flag

def us28(indi, fam, f):
    print("Starting User Story 28 - List siblings in families by decreasing age, i.e. oldest siblings first")
    flag = True
    days_in_year = 365.2425
    x=PrettyTable()
    x.field_names=["Names"]
    for fa in fam:
        n=len(fa["CHIL"])
        val={}
        if(n>1 and fa["CHIL"]!="NA"):
            for i in range(n):
                for j in indi:
                    if(fa["CHIL"][i]==j["INDI"]):
                        latest = date.today()
                        if(j["DEAT"]!="NA"):
                            latest=j["DEAT"].date()
                        age = int((latest - j["BIRT"].date()).days / days_in_year)
                        name=j["NAME"]
                        name1=name.replace('/',' ')
                        val.update({name1:age})
            result = sorted(val.items() , key=lambda t : t[1] , reverse=True)
            x.add_row([result])
    print(x)
    f.write(str(x))
    print("User Story 28 Completed")
    return flag

def us24(indi,fam,f):
    print("Starting User Story 24-No more than one family with the same spouses by name and the same marriage date should appear in a GEDCOM file")
    flag=True
    for individual in indi:
        n=len(individual["FAMS"])
        name=[]*n
        d=[]*n
        if(n>1 and individual["FAMS"]!='NA'):
            name.append(individual["FAMS"])
            for i in range(n):
                for f in fam:
                    if(individual["FAMS"][i]==f["FAM"]):
                        d.append(f["MARR"])
            dat=set()
            na=individual["NAME"].replace('/', ' ')
            for d in d:
                if d in dat:
                    print(f"{na} one family with the same spouses by name and the same marriage date should appear in a GEDCOM file ")
                    f.write(f"{na} one family with the same spouses by name and the same marriage date should appear in a GEDCOM file ")
                dat.add(d)
    print("User Story 24 Completed")
    return flag


def us37(indi,fam,f):
    print("Starting User Story 37-List all living spouses and descendants of people in a GEDCOM file who died in the last 30 days")
    flag=True
    x=PrettyTable()
    x.field_names=["Name","HUSBAND/WIFE/CHILDREN","FAMILY_ID","GENDER"]
    for family in fam:
        count=0
        for inv in indi:
            if(family['HUSB']==inv['INDI'] and inv['DEAT']=='NA'):
                count=count+1
                name=inv['NAME'].replace('/', ' ')
                val="HUSBAND"
                fid=family['FAM']
                gen=inv['SEX']
            if(family['WIFE']==inv['INDI'] and inv['DEAT']=='NA'):
                count=count+1
                name=inv['NAME'].replace('/', ' ')
                val="WIFE"
                fid=family['FAM']
                gen=inv['SEX']
        if(count==1):
            x.add_row([name,val,fid,gen])
            if(family['CHIL']!='NA'):
                for i in range(len(family['CHIL'])):
                    for invd in indi:
                        if(family["CHIL"][i]==invd['INDI'] and invd['DEAT']=='NA'):
                            name1=invd['NAME'].replace('/', ' ')
                            val="CHILDREN"
                            fid=family['FAM']
                            gen=inv['SEX']
                            x.add_row([name1,val,fid,gen])
    print(x)
    f.write(str(x))
    print("User Story 37 Completed")
    return flag