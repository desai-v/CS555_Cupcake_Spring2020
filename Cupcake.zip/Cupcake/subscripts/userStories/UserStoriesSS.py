from datetime import datetime
from datetime import timedelta

import prettytable

from subscripts.userStories.UserStories_MP import getIndiByID, getFamByID
from subscripts.userStories.UserStories_Pratik_Deo import getAgeById

# Sprint 1 

def us11(indi, fam, f):
    print("User Story 11 - Marriage should not occur during marriage to another spouse, Running")
    flag = True
    for individual in indi:
        if individual["FAMS"] != 'NA':
            if len(individual["FAMS"]) > 1:
                spouse = list()
                for sp in individual["FAMS"]:
                    s = getFamByID(fam, sp)
                    spouse.append(s)
                for sp1 in spouse:
                    check = sp1['DIV']
                    for sp2 in spouse:
                        if sp1 != sp2:
                            if sp2["MARR"] != 'NA':
                                if check != 'NA':
                                    if sp1["MARR"] < sp2["MARR"]:
                                        if sp2["MARR"] < check:
                                            f.write(
                                                f"ERROR: FAMILY : US11 : {individual['INDI']} : Individual is in mutliple families at once  \n")
                                            flag = False
                if individual["SEX"] == 'F':
                    spouse2 = list()
                    for sp3 in individual["FAMS"]:
                        s = getFamByID(fam, sp3)
                        infoindi = getIndiByID(indi, s["HUSB"])
                        spouse2.append(infoindi)
                    for sp1 in spouse:
                        for sp2 in spouse2:
                            if sp1["HUSB"] != sp2["INDI"]:
                                if sp2["DEAT"] != 'NA':
                                    if sp1["MARR"] < sp2["DEAT"]:
                                        f.write(
                                            f"ERROR: FAMILY : US11 : {individual['INDI']} : Individual is in mutliple families at once  \n")
                                        flag = False
                if individual["SEX"] == 'M':
                    spouse2 = list()
                    for sp3 in individual["FAMS"]:
                        s = getFamByID(fam, sp3)
                        infoindi = getIndiByID(indi, s["WIFE"])
                        spouse2.append(infoindi)
                    for sp1 in spouse:
                        for sp2 in spouse2:
                            if sp1["WIFE"] != sp2["INDI"]:
                                if sp2["DEAT"] != 'NA':
                                    if sp1["MARR"] < sp2["DEAT"]:
                                        f.write(
                                            f"ERROR: FAMILY : US11 : {individual['INDI']} : Individual is in mutliple families at once  \n")
                                        flag = False
    print("User Story 11 Completed")
    return flag

# Parents should not be too old User Story 12

def us12(indi, fam, f):
    print("User Story 12 - Parents  not too old , Running")
    flag = True
    for family in fam:
        fatherbirth = 'NA'
        motherbirth = 'NA'
        # CHECKING FOR BIRTH DATES OF MOTHER AND FATHER
        for person in indi:
            if family["HUSB"] == person["INDI"]:
                if person["BIRT"] != 'NA':
                    fatherbirth = person["BIRT"] + timedelta(weeks=4171.43)
            if family["WIFE"] == person["INDI"]:
                if person["BIRT"] != 'NA':
                    motherbirth = person["BIRT"] + timedelta(weeks=3128.57)
        if family["CHIL"] != 'NA':
            for child in family["CHIL"]:
                childobj = next(
                    (item for item in indi if item["INDI"] == child), False)
                if childobj != "NA" and fatherbirth != "NA" and motherbirth != "NA":
                    # checking if child is born after death of parents
                    if childobj["BIRT"] > motherbirth or childobj["BIRT"] > fatherbirth:
                        print(
                            f"Indi id -> {childobj['INDI']}, Parents are too old")
                        f.write(
                            f"Error: INDIVIDUAL: US12: {childobj['INDI']} {childobj['NAME']} Parents are too old\n")
                        flag = False
    if flag:
        print("User Story 9 Completed")
        return True
    else:
        return False


# Sprint 2 

# Birth before Marriage
def us02(indi, fam, f):
    print("User Story 2 - Birth before Marriage, Running")
    # SETTING 8
    flag = True
    for families in fam:
        for person in indi:
            if families['HUSB'] == person['INDI'] or families['WIFE'] == person['INDI']:
                # CHECK IF PERSON HAS BIRTHDATE
                if person['BIRT'] == 'NA':
                    print("NO BIRTHDATE FOUND")
                    f.write(
                        f"Error: INDIVIDUAL: US02: {person['INDI']} {person['NAME']} birthdate not found \n")
                    flag = False
                # SETTING M = BIRTHDATE
                m = person['BIRT']
                # COMPARING MARRIAGE DATE TO BIRTHDATE
                if families['MARR'] < m:
                    print(
                        f" User Story 02  Error: {person['INDI']} {person['NAME']} was born before marriage")
                    f.write(
                        f"Error: INDIVIDUAL: US02: {person['INDI']} {person['NAME']} was born before marriage\n")
                    flag = False
    if flag:
        print("User Story 2 Completed")
        return True
    else:
        return False


# Birth before death of parents


def us09(indi, fam, f):
    print("User Story 9 - Birth before death of parents, Running")
    # SETTING FLAG
    flag = True
    for family in fam:
        fatherdeath = 'NA'
        motherdeath = 'NA'
        # CHECKING FOR DEATH DATES OF MOTHER AND FATHER
        for person in indi:
            if family["HUSB"] == person["INDI"]:
                if person["DEAT"] != 'NA':
                    fatherdeath = person["DEAT"] + timedelta(weeks=36)

            if family["WIFE"] == person["INDI"]:
                if person["DEAT"] != 'NA':
                    motherdeath = person["DEAT"]
        if family["CHIL"] != 'NA':
            for child in family["CHIL"]:
                childobj = next(
                    (item for item in indi if item["INDI"] == child), False)
                if childobj != "NA":
                    if fatherdeath != "NA":
                        # checking if child is born after death of parents
                        if childobj["BIRT"] > fatherdeath:
                            print(
                                f"Indi id -> {childobj['INDI']}, Birth after death of parents")
                            f.write(
                                f"Error: INDIVIDUAL: US09: {childobj['INDI']} {childobj['NAME']} Birth after death of parents  \n")
                            flag = False
                    if motherdeath != "NA":
                        if childobj["BIRT"] > motherdeath:
                            print(
                                f"Indi id -> {childobj['INDI']}, Birth after death of parents")
                            f.write(
                                f"Error: INDIVIDUAL: US09: {childobj['INDI']} {childobj['NAME']} Birth after death of parents  \n")
                            flag = False
    if flag:
        print("User Story 9 Completed")
        return True
    else:
        return False

# Sprint 3

def us30(indi, fam, f):
    print("User Story 30 - List all living married, running")
    f.write("Info: FAMILY: US30: List all living married, running \n")
    living_married = list()
    ftable = prettytable.PrettyTable()
    ftable.field_names = ["FAM ID", "NAME"]
    # Iterating over indi
    for individual in indi:
        # If Alive
        if individual["DEAT"] == "NA":
            # If has Wife
            if individual["FAMS"] != "NA":
                # Append to List
                living_married.append(individual)
    for indi1 in living_married:
        ftable.add_row([indi1["INDI"],indi1["NAME"]])

    f.write(f"{str(ftable)} \n")
    print("User Story 30 Completed")
    return living_married



# User Story 33, List orphans
# List all orphaned children (both parents dead and child < 18 years old) in a GEDCOM file
def us33(indi, fam, f):
    print("User Story 33 - List orphans, running")

    f.write("Info: INDIVIDUAL: US33: List orphaned kids \n")
    ftable = prettytable.PrettyTable()
    # adding fieldnames
    ftable.field_names = ["INDI ID", "NAME"]

    orphans = list()
    for family in fam:
        children_ids = family["CHIL"]
        if children_ids == "NA":
            continue
        husb = getIndiByID(indi, family["HUSB"])
        wife = getIndiByID(indi, family["WIFE"])
        if husb["DEAT"] == "NA" or wife["DEAT"] == "NA":
            continue

        # both parents are dead
        for i in children_ids:
            child = getIndiByID(indi, i)
            if child["DEAT"] != "NA":
                continue

            a = calculateage(child["BIRT"], "NA")
            if int(calculateage(child["BIRT"], "NA")) < 18:
                ftable.add_row([child["INDI"], child["NAME"]])
                orphans.append(child)

    f.write(str(f"{ftable} \n"))
    print("User Story 33 Completed")
    return orphans

# Sprint 4 

def us35(indi, fam, f):
    # Created empty list to store recent births
    recent_birth = list()
    print("User Story 35-List recent births")
    # Iterating over individuals
    for individuals in indi:
        # Getting todays date
        todays_date = datetime.today()
        age = individuals["BIRT"]
        # Comparing today's date to 30 days constraint
        if 0 < (todays_date - age).days <= 30:
            recent_birth.append(individuals)

    print("User Story 35 Completed")
    return recent_birth

# List upcoming birthdays
# List all living people in a GEDCOM file whose birthdays occur in the next 30 days
def us38(indi, fam, f):
    print("User Story 38 - List upcoming birthdays, running")
    f.write("Info: INDIVIDUAL: US38: List upcoming birthdays \n")
    ftable = prettytable.PrettyTable()
    # adding fieldnames
    ftable.field_names = ["INDI ID", "NAME", "BIRTH DATE"]

    upcoming_birthdays = list()
    for individual in indi:
        if individual["DEAT"] != "NA":
            continue

        # isAlive
        todays_date = datetime.today()
        birth_day = individual["BIRT"]
        birth_day = birth_day.replace(year=todays_date.year)
        if birth_day < todays_date:
            birth_day = birth_day.replace(year=todays_date.year+1)

        if 0 < (birth_day - todays_date).days <= 30:
            upcoming_birthdays.append(individual)
            ftable.add_row([individual["INDI"], individual["NAME"], individual["BIRT"]])

    f.write(f"{str(ftable)} \n")
    print("User Story 38 Completed")
    return upcoming_birthdays







