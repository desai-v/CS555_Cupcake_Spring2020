# This function will call all the user story functions (from userStories folder's scripts)
# Returns true only if every story checks out, or returns false
from subscripts.userStories.UserStoriesVD import us01, us10, us15, us16, us21, us22
from subscripts.userStories.UserStoriesDP import us03, us08, us06, us04, us14, us17
from subscripts.userStories.UserStoriesYD import us05, us18, us20, us23, us28
from subscripts.userStories.UserStoriesSS import us02, us09, us12, us11, us30, us33


def objectvalid(indi, fam, f):
    f = open("Output_Project.txt", "a")
    f.write("\n \n")
    us01(indi, fam, f)
    us02(indi, fam, f)
    us03(indi, fam, f)
    us04(indi, fam, f)
    us05(indi, fam, f)
    us06(indi, fam, f)
    us08(indi, fam, f)
    us09(indi, fam, f)
    us10(indi, fam, f)
    us11(indi, fam, f)
    us12(indi, fam, f)
    us14(indi, fam, f)
    us15(indi, fam, f)
    us16(indi, fam, f)
    us17(indi, fam, f)
    us18(indi, fam, f)
    us20(indi, fam, f)
    us21(indi, fam, f)
    us22(indi, fam, f)
    us23(indi, fam, f)
    us28(indi, fam, f)
    us30(indi, fam, f)
    us33(indi, fam, f)
    f.close()
    return True
