
Please load the folder as a "project" and then run the script "Project_Main_CS555.py"

output file: Output_Project.txt
